<html>
    @include('frontend.head');
    <body>
      @include('frontend.nav');

                  <!-- headimage -->
                  <div class="headerimg2">
                    <div class="over"></div>
                      <h1>SUPPLIERS</h1>
                      <img src="/img/leaf-white.png" alt="">
                </div>

                  <div class="contents">
                  <div class="cattitle">
                      <h5>CATEGORY/VEGETABLES</h5>
                  </div>

                 
                  <div class="catsort">
                      <div style="flex-grow: 1"><h5>DATES</h5> <i class="fas fa-caret-down"></i></div>
                      <div style="flex-grow: 1"><h5>PRICE</h5><i class="fas fa-caret-down"></i></div>
                      <div style="flex-grow: 6"></div>
                      <div style="flex-grow: 1">
                          <h5>VIEW</h5> <select>
                            <option value="6">6</option>
                            <option value="4">4</option>
                            
                          </select>
                      </div>
                      <div style="flex-grow: 1">
                          <h5>SORT BY</h5>  <select>
                            <option value="popularity">Popularity</option>
                            <option value="recent">Recent</option>
                            
                          </select>
                      </div>
                    </div>
                    
                  
             

                  <div class="suppliers">
                      <div class="productHeading">
                          <h1>SUPPLIERS</h1>
                          <img src="img/leaf-GREEN.png" alt="" class="leaf">
                      </div>
                 <ul class="supp-list">
                    <a href="supplier-info">
                        <div class="supp-item">
                                <li>
                                        <img src="img/farmer.jpg" alt="">
                                        <h6>MIRA KHADKA</h6>
                                        <div class="star">
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                          </div>
                                          <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                        <button>PROFILE</button>
                                    </li>
                            </div>
                          </a>
                          <a href="supplier-info">
                              <div class="supp-item">
                                      <li>
                                              <img src="img/farmer.jpg" alt="">
                                              <h6>MIRA KHADKA</h6>
                                              <div class="star">
                                                  <span class="fa fa-star checked"></span>
                                                  <span class="fa fa-star checked"></span>
                                                  <span class="fa fa-star checked"></span>
                                                  <span class="fa fa-star"></span>
                                                  <span class="fa fa-star"></span>
                                                </div>
                                                <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                              <button>PROFILE</button>
                                          </li>
                                  </div>
                                </a>
                                <a href="supplier-info">
                                    <div class="supp-item">
                                            <li>
                                                    <img src="img/farmer.jpg" alt="">
                                                    <h6>MIRA KHADKA</h6>
                                                    <div class="star">
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star checked"></span>
                                                        <span class="fa fa-star"></span>
                                                        <span class="fa fa-star"></span>
                                                      </div>
                                                      <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                                    <button>PROFILE</button>
                                                </li>
                                        </div>
                                      </a>

                <a href="supplier-info">
                <div class="supp-item">
                        <li>
                                <img src="img/farmer.jpg" alt="">
                                <h6>MIRA KHADKA</h6>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                  </div>
                                  <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                <button>PFOFILE</button>
                            </li>
                    </div>
                  </a>
                  <a href="supplier-info">
                      <div class="supp-item">
                              <li>
                                      <img src="img/farmer.jpg" alt="">
                                      <h6>MIRA KHADKA</h6>
                                      <div class="star">
                                          <span class="fa fa-star checked"></span>
                                          <span class="fa fa-star checked"></span>
                                          <span class="fa fa-star checked"></span>
                                          <span class="fa fa-star"></span>
                                          <span class="fa fa-star"></span>
                                        </div>
                                        <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                      <button>PROFILE</button>
                                  </li>
                          </div>
                        </a>
                        <a href="supplier-info">
                            <div class="supp-item">
                                    <li>
                                            <img src="img/farmer.jpg" alt="">
                                            <h6>MIRA KHADKA</h6>
                                            <div class="star">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                              </div>
                                              <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                            <button>PROFILE</button>
                                        </li>
                                </div>
                              </a>
                              <a href="supplier-info">
                                  <div class="supp-item">
                                          <li>
                                                  <img src="img/farmer.jpg" alt="">
                                                  <h6>MIRA KHADKA</h6>
                                                  <div class="star">
                                                      <span class="fa fa-star checked"></span>
                                                      <span class="fa fa-star checked"></span>
                                                      <span class="fa fa-star checked"></span>
                                                      <span class="fa fa-star"></span>
                                                      <span class="fa fa-star"></span>
                                                    </div>
                                                    <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                                  <button>PROFILE</button>
                                              </li>
                                      </div>
                                    </a>
                                    <a href="supplier-info">
                                        <div class="supp-item">
                                                <li>
                                                        <img src="img/farmer.jpg" alt="">
                                                        <h6>MIRA KHADKA</h6>
                                                        <div class="star">
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="fa fa-star"></span>
                                                            <span class="fa fa-star"></span>
                                                          </div>
                                                          <div><h4>PRODUCTS:</h4> <h5>Tomato, Onion, Rice</h5><br></div> 
                                                        <button>PROFILE</button>
                                                    </li>
                                            </div>
                                          </a>
                 </ul>

                 <div class="centerPagination">
                    <div class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                        <a href="#" class="active">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">&raquo;</a>
                      </div>
                      </div>
                </div>
               
               
              </div>
              

                @include('frontend.footer');
              
    </body>
</html>