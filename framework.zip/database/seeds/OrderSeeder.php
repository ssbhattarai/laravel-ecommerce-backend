<?php

use App\Order;
use App\OrderItem;
use Illuminate\Database\Seeder;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data1 = new Order;
        $data1->user_id = 1;
        $data1->billing_email = "data1@example.com";
        $data1->billing_name = "data1";
        $data1->billing_city = "ktm ";
        $data1->billing_province = "3";
        $data1->billing_phone = "989898989";
        $data1->save();

        // $data1 = new OrderItem;
        // $data1->qty = 14;
        // $data1->save();
    }
}
