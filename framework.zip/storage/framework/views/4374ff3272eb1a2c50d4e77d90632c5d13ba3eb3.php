 <nav id="navbar2" class="navbar navbar-expand-sm fixed-top navbar-light">
              <a class="navbar-brand" href="/"><img src="/img/logoblack.png" alt="" class="logo" ></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbarLinks3 mx-auto">
                    <li class="nav-item">
                      <a class="nav-link" href="/">HOME</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">ABOUT US</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">CONTACT US</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">CATEGORY</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="products">PRODUCT</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="supliers">SUPPLIER</a>
                    </li>
                    
                  </ul>
                  <div id="naviconblock2">
                  <ul class="nav pl-auto">
                      <li class="nav-icon">
                          <a href="" ><i class="fas fa-search" id="navicon"></i></a>
                      </li>
                      <li class="nav-icon">
                              <a href=""><i class="fas fa-shopping-cart" id="navicon"></i></a>
                          </li>
                      <li class="nav-icon">
                           <a href=""><i class="fas fa-user" id="navicon"></i></a>
                      </li>
  
                  </ul>
                </div>
            </div>
          </nav><?php /**PATH /home/zeref/Documents/myBlogApp/agriculture/resources/views/frontend/nav.blade.php ENDPATH**/ ?>