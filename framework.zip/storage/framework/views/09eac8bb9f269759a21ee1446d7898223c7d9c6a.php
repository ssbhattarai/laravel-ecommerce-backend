<!DOCTYPE html>
<html>
<head>
    <title>Page not found - 404</title>
</head>
<body>
    <h1 style="text-align: center; margin-top:178px"><b>Error 404</b></h1>
 
<h2 style="color:red; text-align:center;">The page your looking for is not available
    <a href="<?php echo e(route('login')); ?>">Click here</a>
</h2> 
</body>
</html>


<?php /**PATH /home/zeref/Documents/myBlogApp/agriculture/resources/views/errors/404.blade.php ENDPATH**/ ?>