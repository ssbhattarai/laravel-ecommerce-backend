 <footer>
                   <div class="footer">
                      <nav id="indexnavbar2" class="navbar navbar-expand-sm fixed-top navbar-light">
                          <a class="navbar-brand" href="/"><img src="/img/logoblack.png" alt="" class="logo" ></a>
                        
                          <div class="collapse navbar-collapse" id="navbarSupportedContent">
                              <ul class="navbarLinks2 mx-auto">
                                  <li class="nav-item2">
                                    <a class="nav-link" href="/">HOME</a>
                                  </li>
                                  <li class="nav-item2">
                                    <a class="nav-link" href="#">ABOUT US</a>
                                  </li>
                                  <li class="nav-item2">
                                    <a class="nav-link" href="#">CONTACT US</a>
                                  </li>
                                  <li class="nav-item2">
                                    <a class="nav-link" href="#">CATEGORY</a>
                                  </li>
                                  <li class="nav-item2">
                                    <a class="nav-link" href="products">PRODUCT</a>
                                  </li>
                                  <li class="nav-item2">
                                    <a class="nav-link" href="supliers">SUPPLIER</a>
                                  </li>
                                  
                                </ul>
                                <div id="naviconblock2">
                                <ul class="nav pl-auto">
                                    <li class="nav-icon">
                                        <a href="" class="nav-link"><i class="fab fa-facebook" id="navicon"></i></a>
                                    </li>
                                    <li class="nav-icon">
                                            <a href="" class="nav-link"><i class="fab fa-instagram" id="navicon"></i></a>
                                        </li>
                
                                </ul>
                              </div>
                          </div>
                        </nav>
                      

                        <div class="copyright">
                            <div  class="copy"><p class="text-muted">Copyright © 2019 Pixel Creatives. All Rights Reserved</p></div>
                            <div  class="copyspace"></div>
                            <div class="copy2"><p class="text-muted">This is a website.</p></div>
                          </div>


                      </div>
                    
                 </footer>
                 
                

                 <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
                 <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
                 <script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
                 <script src="<?php echo e(asset('css/script.js')); ?>"></script>

                
                 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
          <?php /**PATH /home/zeref/Documents/myBlogApp/agriculture/resources/views/frontend/footer.blade.php ENDPATH**/ ?>